import fs from 'node:fs';
import { loadGuide } from './loader.mjs';

const DIR = process.argv[2] || '/mnt/user-data/outputs/';
const LABEL = {
  'common-words':'100 Palavras','numeros':'Números','casa-vocabulario':'Vocabulário','verbos':'Verbos','combinacoes':'Combinações',
  'conectores':'Conectores','possessivos':'Possessivos','contracoes':'Contrações','preposicoes':'Preposições','tipos-de-frases':'Tipos de Frases',
  'frases-do-dia':'Frases do Dia','restaurante':'Restaurante','aula1_comunicar_sala_de_aula':'Sala de Aula','expressoes':'Expressões','frases-corrigidas':'Frases Corrigidas'
};
// priority = order new cards are introduced in. Words first.
const ORDER = ['common-words','verbos','combinacoes','numeros','casa-vocabulario','conectores','possessivos','contracoes','preposicoes','tipos-de-frases','frases-do-dia','restaurante','aula1_comunicar_sala_de_aula','expressoes','frases-corrigidas'];
const FLASH_TRACK = { 'common-words':'w','numeros':'w','casa-vocabulario':'w','combinacoes':'w','conectores':'w','possessivos':'w','contracoes':'w',
  'preposicoes':'g','tipos-de-frases':'g','frases-do-dia':'p','restaurante':'p','aula1_comunicar_sala_de_aula':'p','expressoes':'p','frases-corrigidas':'p' };
const DES_TRACK = { verbos:'g', preposicoes:'g', contracoes:'g', conectores:'g', possessivos:'g', combinacoes:'g', restaurante:'p', 'frases-corrigidas':'p' };

const strip = s => String(s ?? '').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
const norm = s => strip(s).toLowerCase().replace(/[.!?…,;:"“”]+$/g,'').replace(/\s+/g,' ').trim();
const slug = s => norm(s).normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,48);
const speakFix = pt => {
  let t = strip(pt);
  if (/ \/ /.test(t)) t = t.replace(/\s*\/\s*/g,', ');
  if (/…/.test(t)) { t = t.replace(/…\s*/g,', ').replace(/,\s*([?!.])/g,'$1').replace(/[,\s]+$/,''); }
  return t;
};
const ALLOWW = new Set(['miami','dave','lisboa','cafe','euros','euro','bairro','alto','harris','sushi','menu','wifi','email','hotel','pizza','portugal','algarve','extra','sandra','rogerio','carla','mariana','andreia','rui','bruno','manuel','cacilhas','cascais','tejo','amelia','marks','sodre','factory','acores','bitoque','tap','bacalhau','vinho','verde','meia','leite','area']);
const plain = w => w.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z]/g,'');
function relocateHint(d) {
  const m = d.q.match(/^(.*?)\s*\(([^)]*)\)\s*$/);
  if (!m) return;
  const ans = new Set(d.a.split(/\s+/).map(plain).filter(w => w.length > 3 && !ALLOWW.has(w)));
  const hits = m[2].split(/\s+/).map(plain).filter(w => ans.has(w));
  if (hits.length) { d.q = m[1]; d.n = d.n ? m[2] + ' · ' + d.n : m[2]; relocated.push(d.a); }
}

const flash = [];   // raw flash cards before merge
const desafio = []; // raw desafio cards
const warn = [];
const relocated = [];
// Card type, so the drill can filter across guides: verb | vocab | func | expr | num | sent
// Conjugated forms that appear in the 100 Palavras guide: they belong to a verb, so they drill with verbs.
const VERB_FORMS = new Set(['temos','estamos','tinha','deve','faz','parece','fazendo','acha','vá','preciso','seja','fez','será','vão','queria','podemos','poderia','precisa','venha','sinto','desculpe','diga']);
const FUNC_SRC = new Set(['conectores','possessivos','contracoes','preposicoes']);
function typeOf(src, o) {
  const c = o.c || '';
  if (src === 'verbos') return 'verb';
  if (src === 'combinacoes') return o.k === 'd' || /^Verbo/.test(c) ? 'verb' : 'vocab';
  if (src === 'common-words') return /^to /.test(o.e || '') || VERB_FORMS.has((o.p || '').toLowerCase()) ? 'verb' : 'vocab';
  if (src === 'numeros') return 'num';
  if (src === 'casa-vocabulario') return 'vocab';
  if (src === 'expressoes') return 'expr';
  if (src === 'preposicoes') return /VERBO/.test(c) ? 'verb' : /DI[ÁA]LOGO/i.test(c) ? 'sent' : 'func';
  if (FUNC_SRC.has(src)) return 'func';
  if (src === 'restaurante' && /^to /.test(o.e || '')) return 'verb';
  return 'sent';   // frases-do-dia, restaurante, aula1, frases-corrigidas, tipos-de-frases
}
function F(src, track, o) { flash.push({ src, track, y: typeOf(src, { ...o, k:'f' }), ...o }); }
function D(src, o) { desafio.push({ src, y: typeOf(src, { ...o, k:'d' }), ...o }); }
const load = (g, probes) => { const r = loadGuide(DIR+g+'.html', probes); if (r.errors.length) warn.push(`${g}: ${r.errors.join(' | ')}`); return r.out; };

// ---- FLASH ----
let o = load('common-words',['WORDS']);
o.WORDS.forEach(w => F('common-words','w',{ c:'Palavras mais comuns', p:w.pt, e:w.def, xp:w.ex_pt, xe:w.ex_en }));

o = load('verbos',['ESSENCIAIS','IRREGULARES','AR_VERBS','ER_IR_VERBS','ALL_CARDS','DESAFIO_CARDS']);
for (const [grp, arr] of [['Essenciais',o.ESSENCIAIS],['Irregulares',o.IRREGULARES],['-AR',o.AR_VERBS],['-ER / -IR',o.ER_IR_VERBS]]) {
  arr.forEach(v => {
    if (v.inf.includes('/')) { warn.push(`verbos: skipped infinitive card for slash entry "${v.inf}"`); return; }
    F('verbos','w',{ c:'Verbo · '+grp, p:v.inf, e:v.en, xp:v.ex_eu, xe:v.ex_eu_en });
  });
}
o.ALL_CARDS.forEach(c => F('verbos','g',{ c:'Conjugação · '+c.cat, p:c.pt, e:c.prompt_en, xp:c.note, xe:c.en_note }));
const verbosDes = o.DESAFIO_CARDS;

o = load('combinacoes',['VERBS','MENTE_WORDS','DESAFIO_GUIADO','DESAFIO_LIVRE','FRAMES']);
o.VERBS.forEach(v => F('combinacoes','w',{ c:'Verbo · Combinações', p:v.inf, e:v.en, xp:v.ex, xe:v.ex_en }));
o.MENTE_WORDS.forEach(m => F('combinacoes','w',{ c:'Advérbios em -mente', p:m.adv, e:m.en, xp:'', xe:'de: '+m.adj }));
const framesById = Object.fromEntries(o.FRAMES.map(f => [f.id, f]));
o.DESAFIO_GUIADO.forEach(d => D('combinacoes',{ c:(framesById[d.frame]?.pattern)||d.frame, q:d.situation, a:d.answer, n:d.en }));
o.DESAFIO_LIVRE.forEach(d => D('combinacoes',{ c:'Situação livre', q:d.situation, a:d.answer, n:d.en }));

o = load('numeros',['numbers','NUM_WORDS']);
o.numbers.forEach(([n, m, f, note]) => {
  F('numeros','w',{ c:'Números', p:m, e:String(n), xp:'', xe:note||'' });
  if (f) F('numeros','w',{ c:'Números · feminino', p:f, e:n+' (feminino)', xp:'', xe:'' });
});
const have = new Set(o.numbers.map(r => String(r[0])));
Object.entries(o.NUM_WORDS).filter(([k]) => /^\d+$/.test(k) && !have.has(k)).forEach(([k,w]) => F('numeros','w',{ c:'Números', p:w, e:k, xp:'', xe:'' }));

o = load('casa-vocabulario',['CATEGORIES']);
o.CATEGORIES.forEach(cat => cat.words.forEach(w => F('casa-vocabulario','w',{ c:'Vocabulário · '+cat.label, p:w.pt, e:w.en, xp:'', xe:'' })));

for (const g of ['conectores','possessivos','contracoes']) {
  o = load(g,['CARDS','DESAFIO_CARDS']);
  o.CARDS.forEach(c => F(g,'w',{ c:LABEL[g]+' · '+c.cat, p:c.pt, e:c.en, xp:c.note, xe:c.en_note }));
  o.DESAFIO_CARDS.forEach(d => D(g,{ c:d.cat, q:d.prompt, a:d.answer, n:d.note }));
}
o = load('preposicoes',['CARDS','DESAFIO_CARDS']);
o.CARDS.forEach(c => F('preposicoes','g',{ c:'Preposições · '+c.cat, p:c.pt, e:c.en, xp:c.note, xe:c.en_note }));
o.DESAFIO_CARDS.forEach(d => D('preposicoes',{ c:d.cat, q:d.prompt, a:d.answer, n:d.note }));

o = load('tipos-de-frases',['FC_CARDS']);
o.FC_CARDS.forEach(c => F('tipos-de-frases','g',{ c:'Tipos de Frases · '+c.type, p:c.pt, e:c.en, xp:'', xe:'' }));

o = load('frases-do-dia',['CATEGORIES']);
o.CATEGORIES.forEach(cat => cat.phrases.forEach(p => F('frases-do-dia','p',{ c:'Frases · '+cat.label, p:p.pt, e:p.en, xp:'', xe:[p.register, p.note].filter(Boolean).join(' · ') })));

for (const g of ['restaurante','frases-corrigidas']) {
  o = load(g,['CARDS','DESAFIO_CARDS']);
  o.CARDS.forEach(c => F(g,'p',{ c:LABEL[g]+' · '+c.cat, p:c.pt, e:c.en, xp:c.note, xe:c.en_note }));
  o.DESAFIO_CARDS.forEach(d => D(g,{ c:d.cat, q:d.prompt, a:d.answer, n:d.note, w:d.waiter_prompt }));
}
o = load('aula1_comunicar_sala_de_aula',['CARDS']);
o.CARDS.forEach(c => F('aula1_comunicar_sala_de_aula','p',{ c:'Sala de Aula · '+c.cat, p:c.pt, e:c.en, xp:'', xe:c.note }));

o = load('expressoes',['EXPRESSOES']);
const EXLAB = { despedidas:'Despedidas', essenciais:'Essenciais', idiomaticas:'Idiomáticas', 'palavras-do-dia':'Palavras do Dia' };
o.EXPRESSOES.forEach(e => {
  const ex = (e.examples||[])[0] || {};
  const card = { c:'Expressões · '+(EXLAB[e.category]||e.category), p:e.pt, e:e.en, xp:strip(ex.pt), xe:strip(ex.en) };
  if (/ \+ /.test(e.pt)) card.sp = strip(ex.pt);   // pattern cards: speak the example, not "mais"
  F('expressoes','p',card);
});

D('verbos',{ c:'__x', q:'', a:'' }); desafio.pop();
verbosDes.forEach(d => D('verbos',{ c:d.cat, q:d.prompt, a:d.answer, n:d.note }));

// ---- MERGE FLASH ----
const idCount = {};
const mk = (kind, base) => { let id = kind + ':' + base, i = 1; while (idCount[id]) id = kind + ':' + base + '-' + (++i); idCount[id] = 1; return id; };
const byPt = new Map(); const merged = []; const collisions = [];
const prio = s => ORDER.indexOf(s);
flash.sort((a,b) => prio(a.src) - prio(b.src));   // stable: keeps in-guide order
flash.forEach(f => {
  f.p = strip(f.p); f.e = strip(f.e); f.xp = strip(f.xp); f.xe = strip(f.xe);
  if (!f.p || !f.e) { warn.push(`flash dropped (missing pt/en): ${f.src} ${JSON.stringify(f).slice(0,80)}`); return; }
  const key = (f.track === 'w' ? norm(f.p) : norm(f.p) + '|' + norm(f.e));
  const hit = byPt.get(key);
  if (hit) {
    if (f.y === 'verb') hit.y = 'verb';   // a verb in any guide is a verb
    if (!hit.s.includes(f.src)) hit.s.push(f.src);
    if (!hit.xp && f.xp) { hit.xp = f.xp; hit.xe = f.xe; }
    if (norm(hit.e) !== norm(f.e)) collisions.push(`${f.p}: "${hit.e}" (${hit.s[0]}) vs "${f.e}" (${f.src})`);
    return;
  }
  const card = { i: mk('f', slug(f.src.slice(0,6)+'-'+f.p)), k:'f', t:f.track, y:f.y, s:[f.src], c:f.c, p:f.p, e:f.e, xp:f.xp, xe:f.xe };
  card.sp = f.sp ? f.sp : speakFix(f.p);
  if (card.sp === card.p) delete card.sp;
  byPt.set(key, card); merged.push(card);
});
merged.forEach((c,i) => c.o = i);

// ---- MERGE DESAFIO ----
const dKey = new Map(); const dMerged = [];
desafio.forEach(d => {
  d.q = strip(d.q); d.a = strip(d.a); d.n = strip(d.n);
  if (!d.q || !d.a) { warn.push(`desafio dropped: ${d.src} ${JSON.stringify(d).slice(0,80)}`); return; }
  relocateHint(d);
  const key = norm(d.a);
  if (dKey.has(key)) { const h = dKey.get(key); if (!h.s.includes(d.src)) h.s.push(d.src); return; }
  const card = { i: mk('d', slug(d.src.slice(0,6)+'-'+d.a)), k:'d', t:DES_TRACK[d.src], y:d.y, s:[d.src], c:d.c, q:d.q, a:d.a, n:d.n };
  if (d.w) card.w = strip(d.w);
  const sp = speakFix(d.a); if (sp !== d.a) card.sp = sp;
  dKey.set(key, card); dMerged.push(card);
});
dMerged.forEach((c,i) => c.o = 10000 + i);

const all = [...merged, ...dMerged];
fs.writeFileSync('cards.json', JSON.stringify(all));
fs.writeFileSync('labels.json', JSON.stringify({ LABEL, ORDER }));

// ---- REPORT ----
const cnt = (arr, f) => arr.reduce((m,x) => (m[f(x)] = (m[f(x)]||0)+1, m), {});
console.log('RAW  flash:', flash.length, ' desafio:', desafio.length);
console.log('KEPT flash:', merged.length, ' desafio:', dMerged.length, ' total:', all.length);
const byY=(arr)=>cnt(arr,c=>c.y);
console.log('by type flash :', JSON.stringify(byY(merged)), ' desafio:', JSON.stringify(byY(dMerged)));
console.log('flash by track  :', JSON.stringify(cnt(merged, c => c.t)));
console.log('flash by source :', JSON.stringify(cnt(flash, c => c.src)));
console.log('desafio by guide:', JSON.stringify(cnt(desafio, c => c.src)));
console.log('merged-away flash:', flash.length - merged.length, ' merged-away desafio:', desafio.length - dMerged.length);
console.log('hints moved out of prompts:', relocated.length, JSON.stringify(relocated));
console.log('\nWARNINGS:'); warn.forEach(w => console.log(' -', w));
console.log('\nMERGES WHERE ENGLISH DIFFERED (review):'); collisions.forEach(c => console.log(' -', c));
console.log('\ncards with slash in speech text:', all.filter(c => /\//.test(c.sp || c.p || c.a || '')).map(c => c.i).join(', ') || 'none');
console.log('JSON bytes:', JSON.stringify(all).length);
