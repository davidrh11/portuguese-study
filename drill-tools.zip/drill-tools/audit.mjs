import fs from 'node:fs';
const cards=JSON.parse(fs.readFileSync('cards.json','utf8'));
const plain=w=>w.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z]/g,'');
const lab=JSON.parse(fs.readFileSync('labels.json','utf8'));
let bad=0; const ids=new Set();
for(const c of cards){
  if(ids.has(c.i)){console.log('DUP id',c.i);bad++;} ids.add(c.i);
  if(!/^[fd]:[a-z0-9-]{1,100}$/.test(c.i)){console.log('BAD id',c.i);bad++;}
  if(c.k==='d'){
    const q=new Set(c.q.split(/\s+/).map(plain));
    const hits=c.a.split(/\s+/).map(plain).filter(w=>w.length>3&&q.has(w));
    if(hits.length){console.log('GIVEAWAY',c.i,hits.join(','),'|',c.q,'=>',c.a);bad++;}
    if(/\//.test(c.sp||c.a)){console.log('SLASH',c.i);bad++;}
  }
  if(c.k==='f'&&/\//.test(c.sp||c.p)){console.log('SLASH',c.i);bad++;}
}
console.log('cards',cards.length,'problems',bad);
