import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { webcrypto } from 'node:crypto';
import worker from './portuguese-sync-worker.js';
const require = createRequire('/tmp/jsd/');
const { JSDOM } = require('jsdom');

let pass = 0, fail = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log('  ok  ', name); } catch (e) { fail++; console.log('  FAIL', name, '\n       ', (e.stack || e.message).split('\n').slice(0, 3).join('\n        ')); } };

const html = fs.readFileSync('drill.html', 'utf8');
const URL_PAGE = 'https://davidrh11.github.io/portuguese-study/drill.html';
class FakeKV { constructor() { this.m = new Map(); this.puts = 0; } async get(k, ty) { const v = this.m.get(k); return v == null ? null : (ty === 'json' ? JSON.parse(v) : v); } async put(k, v) { this.puts++; this.m.set(k, v); } }
const kv = new FakeKV();
const net = { online: true, ttsCalls: 0, syncCalls: 0 };

function device(name) {
  const timers = [];
  const dom = new JSDOM(html, {
    url: URL_PAGE, runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(w) {
      w.crypto.getRandomValues = a => webcrypto.getRandomValues(a);
      Object.defineProperty(w.crypto, 'subtle', { value: webcrypto.subtle, configurable: true });
      w.Audio = class { constructor(u) { this.u = u; } play() { w.__played = (w.__played || 0) + 1; return Promise.resolve(); } };
      w.URL.createObjectURL = () => 'blob:fake';
      w.setInterval = fn => { timers.push(fn); return timers.length; };
      w.clearInterval = () => {};
      w.confirm = () => true;
      Object.defineProperty(w.navigator, 'onLine', { get: () => net.online, configurable: true });
      w.fetch = async (url, init = {}) => {
        if (!net.online) throw new TypeError('offline');
        if (String(url).includes('portuguese-tts')) { net.ttsCalls++; return new Response(new Blob(['x']), { status: 200 }); }
        if (String(url).includes('portuguese-sync')) {
          net.syncCalls++;
          const req = new Request(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://davidrh11.github.io' }, body: init.body });
          return worker.fetch(req, { PT_DRILL: kv });
        }
        throw new Error('unexpected fetch ' + url);
      };
    },
  });
  const w = dom.window, d = w.document;
  const $ = id => d.getElementById(id);
  const click = el => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
  const visible = id => $(id).style.display !== 'none';
  const tick = () => new Promise(r => setTimeout(r, 25));
  return { name, w, d, $, click, visible, tick, timers, store: () => JSON.parse(w.localStorage.getItem('ptd.progress.v1') || '{}') };
}
const settle = async (...ds) => { for (let i = 0; i < 8; i++) for (const x of ds) await x.tick(); };

// -------------------------------------------------------------------
console.log('\nSINGLE DEVICE: flashcards');
const A = device('A');
await settle(A);
await t('page boots with no script errors and shows the home screen', () => {
  assert.ok(A.visible('home')); assert.ok(!A.visible('session'));
  assert.match(A.$('btnStart').textContent, /Começar · 15 cartões/);   // 15 new/day cap
  assert.equal(A.$('tNew').textContent, '15'); assert.equal(A.$('tDue').textContent, '0');
});
await t('default selection is Flashcards · Palavras · PT→EN · 20', () => {
  const on = id => [...A.d.querySelectorAll('#' + id + ' button.on')].map(b => b.dataset.v);
  assert.deepEqual(on('segMode'), ['f']); assert.deepEqual(on('segTrack'), ['w']); assert.deepEqual(on('segDir'), ['r']); assert.deepEqual(on('segSize'), ['20']);
});
await t('track buttons show card counts and Desafio disables empty tracks', () => {
  const labels = [...A.d.querySelectorAll('#segTrack button')].map(b => b.textContent);
  assert.ok(labels[0].startsWith('Palavras (') && labels.length === 4);
  A.click(A.d.querySelector('#segMode button[data-v="d"]'));
  const w = [...A.d.querySelectorAll('#segTrack button')].find(b => b.dataset.v === 'w');
  assert.ok(w.disabled); assert.equal(A.d.querySelector('#segTrack button.on').dataset.v !== 'w', true);
  A.click(A.d.querySelector('#segMode button[data-v="f"]'));
  A.click(A.d.querySelector('#segTrack button[data-v="w"]'));
});
await t('type chips: Todos is on by default, first tap selects only that type, tapping again returns to all', () => {
  const chips = () => [...A.d.querySelectorAll('#chipsType button')];
  assert.ok(chips().length === 7 && /^Todos/.test(chips()[0].textContent) && chips()[0].classList.contains('on'));
  const verbs = chips().find(b => /^Verbos/.test(b.textContent));
  A.click(verbs);
  assert.deepEqual(chips().filter(b => b.classList.contains('on')).map(b => b.textContent.replace(/ \(.*/, '')), ['Verbos']);
  A.click(chips().find(b => /^Verbos/.test(b.textContent)));
  assert.ok(chips()[0].classList.contains('on'));
});
await t('verb type: a session only contains verb cards', () => {
  A.click([...A.d.querySelectorAll('#chipsType button')].find(b => /^Verbos/.test(b.textContent)));
  A.click(A.d.querySelector('#segTrack button[data-v="all"]'));
  A.click(A.$('btnStart'));
  const n = A.w.eval('S.queue.length'), bad = A.w.eval('S.queue.filter(q => q.card.y !== "verb").length');
  assert.ok(n > 5 && bad === 0, n + ' cards, ' + bad + ' not verbs');
  A.click(A.$('btnQuit'));
  A.click([...A.d.querySelectorAll('#chipsType button')][0]);   // back to Todos
  A.click(A.d.querySelector('#segTrack button[data-v="w"]'));
});
await t('start session: first card is a PT word with answer hidden (blurred) and no grade buttons', () => {
  A.click(A.$('btnStart'));
  assert.ok(A.visible('session')); assert.ok(A.visible('flashBlock')); assert.ok(!A.visible('desafioBlock'));
  assert.equal(A.$('sCounter').textContent, '1 / 15');
  assert.ok(A.$('fFrontPt').textContent.length > 0 && A.visible('fFrontPt') && !A.visible('fFrontEn'));
  assert.ok(!A.$('fAns').classList.contains('revealed')); assert.ok(!A.visible('fGrade')); assert.ok(A.visible('fReveal'));
});
await t('reveal shows answer, plays audio, shows grade buttons; example EN stays blurred until tapped', async () => {
  A.click(A.$('fReveal')); await settle(A);
  assert.ok(A.$('fAns').classList.contains('revealed')); assert.ok(A.visible('fGrade')); assert.ok(!A.visible('fReveal'));
  assert.ok(A.w.__played >= 1); assert.ok(!A.$('fExEn').classList.contains('revealed'));
  A.click(A.$('fExEn')); assert.ok(A.$('fExEn').classList.contains('revealed'));
});
await t('prefetch ran for the upcoming cards (look-ahead audio)', () => { assert.ok(net.ttsCalls >= 2, 'tts calls ' + net.ttsCalls); });
await t('grade right: progress saved for that card as box 2, counter advances', () => {
  A.click(A.$('fYes'));
  const keys = Object.keys(A.store()); assert.equal(keys.length, 1); assert.match(keys[0], /\|r$/);
  assert.equal(A.store()[keys[0]].b, 2); assert.equal(A.$('sCounter').textContent, '2 / 15');
});
await t('grade wrong: box 1, card comes back later in the same session without re-scheduling', async () => {
  const missedPt = A.$('fFrontPt').textContent;
  A.click(A.$('fReveal')); A.click(A.$('fNo'));
  const rec = Object.entries(A.store()).find(([k, v]) => v.w === 1); assert.ok(rec); assert.equal(rec[1].b, 1);
  let seenAgain = false;
  for (let i = 0; i < 6; i++) { if (A.$('fFrontPt').textContent === missedPt) { seenAgain = true; break; } A.click(A.$('fReveal')); A.click(A.$('fYes')); }
  assert.ok(seenAgain, 'missed card never re-appeared');
  assert.equal(A.$('fCat').textContent.includes('outra vez'), true);
  const before = JSON.stringify(A.store()[rec[0]]);
  A.click(A.$('fReveal')); A.click(A.$('fYes'));                    // right on the retry
  assert.equal(JSON.stringify(A.store()[rec[0]]), before, 'retry must not change the schedule');
});
await t('keyboard: space reveals, 2 = sabia, 1 = não sabia', () => {
  const n0 = Object.keys(A.store()).length;
  A.d.dispatchEvent(new A.w.KeyboardEvent('keydown', { key: ' ', bubbles: true })); assert.ok(A.visible('fGrade'));
  A.d.dispatchEvent(new A.w.KeyboardEvent('keydown', { key: '2', bubbles: true }));
  assert.ok(Object.keys(A.store()).length >= n0);
});
await t('finish the session: summary screen with score and missed list, then back home with updated tiles', async () => {
  let guard = 0;
  while (A.visible('session') && guard++ < 60) { A.click(A.$('fReveal')); A.click(A.$('fYes')); }
  assert.ok(A.visible('done')); assert.match(A.$('doneBig').textContent, /^\d+ \/ 15$/);
  assert.ok(A.$('doneMissed').children.length >= 1);
  A.click(A.$('btnHome')); await settle(A);
  assert.equal(A.$('tToday').textContent, '15'); assert.equal(A.$('tNew').textContent, '0');   // daily cap reached
  assert.ok(A.$('btnStart').disabled); assert.match(A.$('homeMsg').textContent, /limite de novos/);
});
await t('raising the daily limit re-enables new cards', async () => {
  A.d.querySelector('details.more').open = true;
  A.$('newPerDay').value = '20'; A.$('newPerDay').dispatchEvent(new A.w.Event('change', { bubbles: true })); await settle(A);
  assert.equal(A.$('tNew').textContent, '5'); assert.ok(!A.$('btnStart').disabled);
});

// -------------------------------------------------------------------
console.log('\nSINGLE DEVICE: desafio');
await t('desafio: timer expiry does NOT reveal; note hidden until reveal; waiter prompt shown', async () => {
  A.click(A.d.querySelector('#segMode button[data-v="d"]'));
  A.click(A.d.querySelector('#segTrack button[data-v="p"]'));
  A.$('newPerDay').value = '100'; A.$('newPerDay').dispatchEvent(new A.w.Event('change', { bubbles: true })); await settle(A);
  A.click(A.$('btnStart'));
  assert.ok(A.visible('desafioBlock'));
  let guard = 0, sawWaiter = false;
  while (guard++ < 40) {                          // advance until a waiter-prompt card appears
    if (A.visible('dWaiterWrap')) { sawWaiter = true; break; }
    A.click(A.$('dAnswer')); A.click(A.$('dYes'));
  }
  assert.ok(sawWaiter, 'no waiter prompt card in 40 cards');
  assert.ok(A.$('dWaiterText').textContent.length > 3);
  assert.equal(A.$('dNote').textContent, '');
  const nBefore = Object.keys(A.store()).length;
  A.click(A.$('dYes')); A.click(A.$('dNo'));         // grading before reveal must be ignored
  assert.equal(Object.keys(A.store()).length, nBefore, 'graded without revealing');
});
await t('desafio: run the 8s countdown to zero via the captured interval', async () => {
  // restart a fresh card so the interval for it is the last captured
  A.timers.length = 0;
  A.click(A.$('dAnswer')); A.click(A.$('dYes'));   // reveal + grade -> loads next card, registers a new interval
  const fn = A.timers[A.timers.length - 1]; assert.ok(fn, 'no interval registered');
  for (let i = 0; i < 8; i++) fn();
  assert.equal(A.$('dTimerText').textContent, '✓'); assert.equal(A.$('dHint').textContent, 'tempo — toca para revelar');
  assert.ok(!A.$('dAnswer').classList.contains('revealed'), 'must not auto-reveal');
  assert.equal(A.$('dNote').textContent, '');
  A.click(A.$('dAnswer'));
  const note = A.w.eval('cur().card.n') || '';
  assert.ok(A.$('dAnswer').classList.contains('revealed')); assert.ok(A.visible('dActions'));
  assert.equal(A.$('dNote').textContent, note); assert.ok(note.length > 0, 'expected this card to carry a note');
});
await t('desafio giveaway guard: no prompt in the deck contains its own answer words (proper nouns excepted)', () => {
  const cards = A.w.eval('CARDS').filter(c => c.k === 'd');
  const plain = w => w.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z]/g, '');
  const allow = new Set(['miami', 'dave', 'lisboa', 'cafe', 'euros', 'euro', 'bairro', 'alto', 'harris', 'sushi', 'menu', 'wifi', 'email', 'hotel', 'pizza', 'portugal', 'algarve', 'extra', 'bacalhau', 'vinho', 'verde', 'meia', 'leite', 'area']);
  const bad = cards.filter(c => c.a.split(/\s+/).map(plain).filter(x => x.length > 3 && !allow.has(x)).some(x => new RegExp('\\b' + x + '\\b').test(plain(c.q))));
  assert.equal(bad.length, 0, bad.map(c => c.q + ' => ' + c.a).join(' || '));
});
A.click(A.$('btnQuit')); await settle(A);

// -------------------------------------------------------------------
console.log('\nTWO DEVICES + SYNC (real worker code, shared fake KV)');
const P = device('phone'), L = device('laptop');
await settle(P, L);
let code;
await t('phone creates a sync code and pushes; laptop joins with the same code', async () => {
  P.click(P.d.querySelector('[data-tab="sync"]'));
  P.click(P.$('btnMakeCode')); await settle(P, L);
  code = P.w.localStorage.getItem('ptd.sync.code'); assert.match(code, /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  assert.equal(P.$('codeShow').textContent, code); assert.match(P.$('syncPill').textContent, /sincronizado/);
  L.$('codeIn').value = code.toLowerCase().replace(/-/g, ' '); L.click(L.$('btnUseCode')); await settle(P, L);
  assert.equal(L.w.localStorage.getItem('ptd.sync.code'), code);
});
await t('wrong-length code is rejected with a message', async () => {
  const X = device('x'); await settle(X); X.$('codeIn').value = 'ABC'; X.click(X.$('btnUseCode'));
  assert.match(X.$('syncMsg').textContent, /12 letras/); assert.equal(X.w.localStorage.getItem('ptd.sync.code'), null);
});
async function study(dev, n, correct = true) {
  dev.click(dev.d.querySelector('[data-tab="treino"]'));
  dev.click(dev.$('btnHome')); dev.click(dev.$('btnStart'));
  for (let i = 0; i < n; i++) { dev.click(dev.$('fReveal')); dev.click(correct ? dev.$('fYes') : dev.$('fNo')); }
}
await t('phone studies; laptop picks it up on next sync (no overlap, no loss)', async () => {
  P.w.localStorage.setItem('ptd.settings.v1', JSON.stringify({ mode: 'f', track: 'w', dir: 'r', size: 10, newPerDay: 10, gate: true, sources: null }));
  const P2 = P; P2.w.eval('settings = Object.assign(settings, {mode:"f",track:"w",dir:"r",size:10,newPerDay:10})');
  P.click(P.d.querySelector('[data-tab="treino"]')); P.w.eval('refreshHome()');
  P.click(P.$('btnStart'));
  for (let i = 0; i < 10; i++) { P.click(P.$('fReveal')); P.click(P.$('fYes')); }
  await settle(P, L);                                   // finishing a session triggers a sync
  const pk = Object.keys(P.store()); assert.equal(pk.length, 10);
  await L.w.eval('syncNow(true)'); await settle(L);
  assert.deepEqual(Object.keys(L.store()).sort(), pk.sort());
});
await t('laptop continues with the NEXT new words (not the ones the phone already did)', async () => {
  L.w.eval('settings = Object.assign(settings, {mode:"f",track:"w",dir:"r",size:10,newPerDay:30}); refreshHome()');
  L.click(L.d.querySelector('[data-tab="treino"]'));
  const phoneIds = new Set(Object.keys(P.store()).map(k => k.split('|')[0]));
  L.click(L.$('btnStart'));
  const seen = [];
  for (let i = 0; i < 10; i++) { seen.push(L.w.eval('cur().card.i')); L.click(L.$('fReveal')); L.click(L.$('fYes')); }
  assert.ok(seen.every(id => !phoneIds.has(id)), 'laptop repeated cards the phone already did');
  await settle(P, L);
  await P.w.eval('syncNow(true)'); await settle(P);
  assert.equal(Object.keys(P.store()).length, 20); assert.equal(Object.keys(L.store()).length, 20);
});
await t('offline: grading still works and is kept; syncs when back online', async () => {
  net.online = false;
  P.w.eval('settings = Object.assign(settings, {mode:"f",track:"w",dir:"p",size:5,newPerDay:50,gate:false}); refreshHome()');
  P.click(P.$('btnStart'));
  for (let i = 0; i < 5; i++) { P.click(P.$('fReveal')); P.click(P.$('fYes')); }
  await settle(P);
  assert.equal(Object.keys(P.store()).length, 25); assert.match(P.$('syncPill').textContent, /offline/);
  assert.equal(Object.keys(L.store()).length, 20);
  net.online = true; P.w.dispatchEvent(new P.w.Event('online')); await settle(P, L);
  await L.w.eval('syncNow(true)'); await settle(L);
  assert.equal(Object.keys(L.store()).length, 25);
});
await t('same card graded on both devices: the later answer wins, no duplicate keys', async () => {
  const k = Object.keys(P.store())[0];
  const early = { ...P.store()[k], b: 2, u: Date.now() - 5000 }, late = { ...P.store()[k], b: 4, u: Date.now() };
  P.w.eval(`progress[${JSON.stringify(k)}] = ${JSON.stringify(early)}; saveProgress();`);
  L.w.eval(`progress[${JSON.stringify(k)}] = ${JSON.stringify(late)}; saveProgress();`);
  await L.w.eval('syncNow(true)'); await P.w.eval('syncNow(true)'); await settle(P, L);
  assert.equal(P.store()[k].b, 4); assert.equal(L.store()[k].b, 4);
});
await t('a wiped device (cleared storage) recovers everything from the server', async () => {
  const fresh = device('ipad'); await settle(fresh);
  fresh.w.localStorage.setItem('ptd.sync.code', code); await fresh.w.eval('syncNow(true)'); await settle(fresh);
  assert.equal(Object.keys(fresh.store()).length, Object.keys(P.store()).length);
});
await t('progress tab renders from real data without errors; hardest list shows misses', async () => {
  P.click(P.d.querySelector('[data-tab="progresso"]')); await settle(P);
  assert.ok(P.$('progTable').querySelectorAll('tr').length >= 4); assert.ok(P.$('srcTable').querySelectorAll('tr').length >= 8);
  assert.ok(P.$('hardList').children.length >= 1);
});
await t('export then import round-trips without changing anything', async () => {
  const before = JSON.stringify(P.store());
  const m = P.w.eval('mergeProgress(progress, JSON.parse(JSON.stringify({progress})).progress)'); assert.equal(m.changed, false);
  assert.equal(JSON.stringify(P.store()), before);
});
await t('unlink removes the code locally but keeps progress', async () => {
  const n = Object.keys(L.store()).length;
  L.click(L.d.querySelector('[data-tab="sync"]')); L.click(L.$('btnUnlink')); await settle(L);
  assert.equal(L.w.localStorage.getItem('ptd.sync.code'), null); assert.equal(Object.keys(L.store()).length, n);
  assert.match(L.$('syncPill').textContent, /sem sincroniza/);
});
console.log('\nKV writes during whole run:', kv.puts, '| sync calls:', net.syncCalls, '| tts calls:', net.ttsCalls);
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
