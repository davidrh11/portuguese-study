import fs from 'node:fs';
import assert from 'node:assert/strict';
import worker from './portuguese-sync-worker.js';

let pass = 0, fail = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log('  ok  ', name); } catch (e) { fail++; console.log('  FAIL', name, '\n       ', e.message.split('\n')[0]); } };

// ---------- extract CORE from the real page ----------
const html = fs.readFileSync('drill.html', 'utf8');
const core = html.match(/\/\/ CORE-START([\s\S]*?)\/\/ CORE-END/)[1];
const C = new Function(core + '; return { INTERVALS, dayIndex, keyOf, isRec, applyResult, mergeProgress, buildSession, stageOf, normCode, groupCode, makeCode, speechText };')();
const CARDS = JSON.parse(fs.readFileSync('cards.json', 'utf8'));

console.log('\nCLIENT LOGIC');
await t('applyResult: new card right -> box 2, due in 3 days', () => {
  const r = C.applyResult(undefined, true, 100, 5);
  assert.deepEqual(r, { b: 2, d: 103, f: 100, l: 100, n: 1, w: 0, u: 5 });
});
await t('applyResult: new card wrong -> box 1, due tomorrow, w=1', () => {
  const r = C.applyResult(undefined, false, 100, 5);
  assert.equal(r.b, 1); assert.equal(r.d, 101); assert.equal(r.w, 1);
});
await t('box ladder 2->3->4->5 then caps at 5; intervals 3,7,16,35', () => {
  let r = C.applyResult(undefined, true, 0, 1); const days = [r.d - 0];
  for (let i = 0; i < 4; i++) { r = C.applyResult(r, true, r.d, 2 + i); days.push(r.d - r.l); }
  assert.equal(r.b, 5); assert.deepEqual(days, [3, 7, 16, 35, 35]);
});
await t('a miss drops any box back to 1 and keeps first-seen day', () => {
  let r = C.applyResult(undefined, true, 10, 1); r = C.applyResult(r, true, 13, 2); r = C.applyResult(r, false, 20, 3);
  assert.equal(r.b, 1); assert.equal(r.f, 10); assert.equal(r.w, 1); assert.equal(r.n, 3);
});
await t('mergeProgress: newer wins, older ignored, junk rejected, input not mutated', () => {
  const a = { x: { b: 2, d: 5, f: 1, l: 1, n: 1, w: 0, u: 100 } };
  const snap = JSON.stringify(a);
  const m = C.mergeProgress(a, { x: { b: 4, d: 9, f: 1, l: 2, n: 2, w: 0, u: 200 }, y: { b: 1, d: 2, f: 1, l: 1, n: 1, w: 1, u: 50 }, bad: { b: 9 } });
  assert.equal(m.map.x.b, 4); assert.ok(m.map.y); assert.ok(!m.map.bad); assert.ok(m.changed);
  assert.equal(JSON.stringify(a), snap);
  const m2 = C.mergeProgress(m.map, { x: { b: 1, d: 1, f: 1, l: 1, n: 1, w: 1, u: 10 } });
  assert.equal(m2.map.x.b, 4); assert.equal(m2.changed, false);
});
await t('mergeProgress is commutative and idempotent', () => {
  const A = { a: { b: 2, d: 5, f: 1, l: 1, n: 1, w: 0, u: 10 }, c: { b: 3, d: 5, f: 1, l: 1, n: 1, w: 0, u: 30 } };
  const B = { a: { b: 5, d: 5, f: 1, l: 1, n: 1, w: 0, u: 20 }, d: { b: 1, d: 5, f: 1, l: 1, n: 1, w: 0, u: 5 } };
  const ab = C.mergeProgress(A, B).map, ba = C.mergeProgress(B, A).map;
  assert.deepEqual(ab, ba); assert.deepEqual(C.mergeProgress(ab, B).map, ab);
});
await t('dayIndex: two instants one minute apart across local midnight differ by 1', () => {
  const d = new Date(2026, 9, 8, 23, 59, 30).getTime();
  assert.equal(C.dayIndex(d + 60000) - C.dayIndex(d), 1);
  assert.equal(C.dayIndex(new Date(2026, 9, 8, 0, 0, 1).getTime()), C.dayIndex(new Date(2026, 9, 8, 23, 59, 59).getTime()));
});
const rng = () => 0.5;
const base = { cards: CARDS, progress: {}, mode: 'f', dir: 'r', track: 'w', sources: null, size: 20, newAllowed: 15, today: 1000, gate: true, rng };
await t('fresh session: 15 new (daily cap) even though size is 20, in guide order', () => {
  const s = C.buildSession(base);
  assert.equal(s.items.length, 15); assert.equal(s.newTaken, 15);
  const first15 = CARDS.filter(c => c.k === 'f' && c.t === 'w').sort((a, b) => a.o - b.o).slice(0, 15).map(c => c.i).sort();
  assert.deepEqual(s.items.map(c => c.i).sort(), first15);
});
await t('words track = only words; first new cards come from 100 Palavras', () => {
  const s = C.buildSession(base);
  assert.ok(s.items.every(c => c.t === 'w' && c.k === 'f'));
  assert.ok(s.items.every(c => c.s.includes('common-words') || c.s.includes('verbos')));
});
await t('due cards come first and crowd out new ones; most overdue taken first', () => {
  const words = CARDS.filter(c => c.k === 'f' && c.t === 'w').sort((a, b) => a.o - b.o);
  const prog = {};
  words.slice(0, 30).forEach((c, i) => { prog[c.i + '|r'] = { b: 2, d: 900 + i, f: 800, l: 800, n: 1, w: 0, u: 1 }; });
  const s = C.buildSession({ ...base, progress: prog, size: 20 });
  assert.equal(s.dueTaken, 20); assert.equal(s.newTaken, 0); assert.equal(s.dueTotal, 30);
  const want = words.slice(0, 20).map(c => c.i).sort();
  assert.deepEqual(s.items.map(c => c.i).sort(), want);
});
await t('not-yet-due cards are excluded; due-today cards are included', () => {
  const w = CARDS.filter(c => c.k === 'f' && c.t === 'w')[0];
  const mk = d => ({ [w.i + '|r']: { b: 3, d, f: 1, l: 1, n: 1, w: 0, u: 1 } });
  assert.equal(C.buildSession({ ...base, progress: mk(1001), newAllowed: 0 }).items.length, 0);
  assert.equal(C.buildSession({ ...base, progress: mk(1000), newAllowed: 0 }).items.length, 1);
});
await t('recognition and production progress are independent', () => {
  const w = CARDS.filter(c => c.k === 'f' && c.t === 'w')[0];
  const prog = { [w.i + '|r']: { b: 3, d: 5000, f: 1, l: 1, n: 1, w: 0, u: 1 } };
  const rec = C.buildSession({ ...base, progress: prog, dir: 'r', newAllowed: 1000, size: 1000 });
  const pro = C.buildSession({ ...base, progress: prog, dir: 'p', gate: false, newAllowed: 1000, size: 1000 });
  assert.ok(!rec.items.some(c => c.i === w.i)); assert.ok(pro.items.some(c => c.i === w.i));
});
await t('production gate: EN->PT only offers new words already recognised (box>=2)', () => {
  const ws = CARDS.filter(c => c.k === 'f' && c.t === 'w').sort((a, b) => a.o - b.o);
  const prog = {
    [ws[0].i + '|r']: { b: 2, d: 5000, f: 1, l: 1, n: 1, w: 0, u: 1 },   // recognised
    [ws[1].i + '|r']: { b: 1, d: 5000, f: 1, l: 1, n: 1, w: 1, u: 1 },   // missed, not yet known
  };
  const g = C.buildSession({ ...base, progress: prog, dir: 'p', gate: true });
  assert.deepEqual(g.items.map(c => c.i), [ws[0].i]); assert.ok(g.newBlocked > 0);
  assert.ok(C.buildSession({ ...base, progress: prog, dir: 'p', gate: false }).items.length > 1);
});
await t('desafio mode ignores the gate and only returns desafio cards', () => {
  const s = C.buildSession({ ...base, mode: 'd', dir: 'd', track: 'all', gate: true, size: 500, newAllowed: 500 });
  assert.ok(s.items.length > 100 && s.items.every(c => c.k === 'd'));
});
await t('source filter limits the pool', () => {
  const s = C.buildSession({ ...base, sources: new Set(['numeros']), size: 500, newAllowed: 500 });
  assert.ok(s.items.length > 30 && s.items.every(c => c.s.includes('numeros')));
});
await t('type filter: verbs across guides, and combines with source and track', () => {
  const v = C.buildSession({ ...base, track: 'all', types: new Set(['verb']), size: 900, newAllowed: 900 });
  assert.ok(v.items.length > 100 && v.items.every(c => c.y === 'verb'));
  const guides = new Set(v.items.flatMap(c => c.s));
  assert.ok(guides.has('verbos') && guides.has('combinacoes') && guides.has('common-words'), 'verbs come from several guides: ' + [...guides]);
  const two = C.buildSession({ ...base, track: 'all', types: new Set(['verb', 'expr']), size: 900, newAllowed: 900 });
  assert.ok(two.items.some(c => c.y === 'expr') && two.items.every(c => c.y === 'verb' || c.y === 'expr'));
  const only = C.buildSession({ ...base, track: 'all', types: new Set(['verb']), sources: new Set(['combinacoes']), size: 900, newAllowed: 900 });
  assert.ok(only.items.length > 0 && only.items.every(c => c.y === 'verb' && c.s.includes('combinacoes')));
  const d = C.buildSession({ ...base, mode: 'd', dir: 'd', track: 'all', types: new Set(['verb']), size: 900, newAllowed: 900 });
  assert.ok(d.items.length > 50 && d.items.every(c => c.k === 'd' && c.y === 'verb'));
  const none = C.buildSession({ ...base, types: null, size: 900, newAllowed: 900 });
  assert.ok(none.items.length > v.items.filter(c => c.t === 'w').length);
});
await t('every card has a known type', () => {
  const ok = new Set(['verb', 'vocab', 'func', 'expr', 'num', 'sent']);
  assert.ok(CARDS.every(c => ok.has(c.y)), CARDS.filter(c => !ok.has(c.y)).slice(0, 3).map(c => c.i).join());
});
await t('stageOf buckets', () => {
  assert.equal(C.stageOf(undefined), 'novo'); assert.equal(C.stageOf({ b: 1 }), 'aprender');
  assert.equal(C.stageOf({ b: 3 }), 'rever'); assert.equal(C.stageOf({ b: 5 }), 'dominado');
});
await t('sync code: 12 chars from safe alphabet, grouped 4-4-4, unique, normalises', () => {
  const { randomBytes } = await_crypto(); const seen = new Set();
  for (let i = 0; i < 2000; i++) {
    const code = C.makeCode(() => randomBytes(1)[0]);
    assert.match(code, /^[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}$/); seen.add(code);
  }
  assert.equal(seen.size, 2000);
  assert.equal(C.normCode(' k7qm-x3rd 9twb '), 'K7QMX3RD9TWB'); assert.equal(C.groupCode('K7QMX3RD9TWB'), 'K7QM-X3RD-9TWB');
});
function await_crypto() { return globalThis.__crypto ??= { randomBytes: n => globalThis.crypto.getRandomValues(new Uint8Array(n)) }; }

// ---------- worker ----------
console.log('\nSYNC WORKER');
const ORIGIN = 'https://davidrh11.github.io';
class FakeKV { constructor() { this.m = new Map(); this.puts = 0; } async get(k, t) { const v = this.m.get(k); return v == null ? null : (t === 'json' ? JSON.parse(v) : v); } async put(k, v) { this.puts++; this.m.set(k, v); } }
const H = 'a'.repeat(64), H2 = 'b'.repeat(64);
const rec = (u, b = 2) => ({ b, d: 10, f: 1, l: 1, n: 1, w: 0, u });
const call = (env, body, { method = 'POST', origin = ORIGIN, raw } = {}) => worker.fetch(new Request('https://x.workers.dev/', { method, headers: Object.assign({ 'Content-Type': 'application/json' }, origin ? { Origin: origin } : {}), body: method === 'POST' ? (raw ?? JSON.stringify(body)) : undefined }), env);
const j = async r => JSON.parse(await r.text());

await t('preflight returns 204 with locked-down CORS', async () => {
  const r = await call({ PT_DRILL: new FakeKV() }, null, { method: 'OPTIONS' });
  assert.equal(r.status, 204); assert.equal(r.headers.get('access-control-allow-origin'), ORIGIN);
});
await t('foreign Origin is refused (403)', async () => { assert.equal((await call({ PT_DRILL: new FakeKV() }, { k: H, r: {} }, { origin: 'https://evil.example' })).status, 403); });
await t('GET is 405', async () => { assert.equal((await call({ PT_DRILL: new FakeKV() }, null, { method: 'GET' })).status, 405); });
await t('bad key / bad json -> 400', async () => {
  const env = { PT_DRILL: new FakeKV() };
  assert.equal((await call(env, { k: 'short', r: {} })).status, 400);
  assert.equal((await call(env, null, { raw: '{nope' })).status, 400);
});
await t('missing KV binding gives a clear 500, not a crash', async () => { const r = await call({}, { k: H, r: {} }); assert.equal(r.status, 500); assert.match((await j(r)).error, /PT_DRILL/); });
await t('two devices converge; nothing is lost', async () => {
  const env = { PT_DRILL: new FakeKV() };
  await call(env, { k: H, r: { 'f:a-one|r': rec(100) } });
  const b = await j(await call(env, { k: H, r: { 'f:a-two|r': rec(200) } }));
  assert.deepEqual(Object.keys(b.r).sort(), ['f:a-one|r', 'f:a-two|r']);
  const a = await j(await call(env, { k: H, r: { 'f:a-one|r': rec(100) } }));
  assert.equal(Object.keys(a.r).length, 2);
});
await t('newest record wins per card, older push cannot overwrite', async () => {
  const env = { PT_DRILL: new FakeKV() };
  await call(env, { k: H, r: { 'd:x-y|d': rec(500, 4) } });
  const r = await j(await call(env, { k: H, r: { 'd:x-y|d': rec(100, 1) } }));
  assert.equal(r.r['d:x-y|d'].b, 4);
});
await t('no KV write when nothing changed (protects the free 1,000 writes/day)', async () => {
  const kv = new FakeKV(), env = { PT_DRILL: kv };
  await call(env, { k: H, r: { 'f:a-one|r': rec(100) } }); assert.equal(kv.puts, 1);
  await call(env, { k: H, r: { 'f:a-one|r': rec(100) } }); await call(env, { k: H, r: {} });
  assert.equal(kv.puts, 1);
});
await t('different codes are isolated', async () => {
  const env = { PT_DRILL: new FakeKV() };
  await call(env, { k: H, r: { 'f:a-one|r': rec(100) } });
  assert.deepEqual((await j(await call(env, { k: H2, r: {} }))).r, {});
});
await t('junk records and keys are dropped, extra fields stripped', async () => {
  const env = { PT_DRILL: new FakeKV() };
  const r = await j(await call(env, { k: H, r: { 'f:ok-card|r': { ...rec(1), evil: '<script>' }, '../../etc': rec(1), 'f:bad|x': rec(1), 'f:b2|r': { b: 99 } } }));
  assert.deepEqual(Object.keys(r.r), ['f:ok-card|r']); assert.equal(r.r['f:ok-card|r'].evil, undefined);
});
await t('oversized body -> 413', async () => { assert.equal((await call({ PT_DRILL: new FakeKV() }, null, { raw: JSON.stringify({ k: H, r: {}, pad: 'x'.repeat(1100000) }) })).status, 413); });
await t('storage failure -> 500 json (client keeps local progress)', async () => {
  const kv = { get: async () => { throw new Error('boom'); }, put: async () => {} };
  const r = await call({ PT_DRILL: kv }, { k: H, r: {} }); assert.equal(r.status, 500); assert.equal((await j(r)).error, 'storage error');
});
await t('real-size payload (every card, both directions) fits comfortably', async () => {
  const r = {}; CARDS.forEach(c => (c.k === 'f' ? ['r', 'p'] : ['d']).forEach(d => { r[c.i + '|' + d] = rec(1); }));
  const bytes = JSON.stringify({ k: H, r }).length; const res = await call({ PT_DRILL: new FakeKV() }, { k: H, r });
  assert.equal(res.status, 200); assert.equal(Object.keys((await j(res)).r).length, Object.keys(r).length);
  console.log('       full-deck payload:', Math.round(bytes / 1024), 'KB,', Object.keys(r).length, 'records');
});
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
