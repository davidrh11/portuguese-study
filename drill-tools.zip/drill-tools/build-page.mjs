import fs from 'node:fs';
const tpl = fs.readFileSync('drill.template.html','utf8');
const cards = fs.readFileSync('cards.json','utf8');
const labels = fs.readFileSync('labels.json','utf8');
const LS = new RegExp(String.fromCharCode(0x2028), 'g'), PS = new RegExp(String.fromCharCode(0x2029), 'g');
const safe = j => j.replace(/</g, '\\u003c').replace(LS, '\\u2028').replace(PS, '\\u2029');
const out = tpl
  .replace('__TTS_URL__', 'https://portuguese-tts-speechify.drh-dave.workers.dev')
  .replace('__SYNC_URL__', 'https://portuguese-sync.drh-dave.workers.dev')
  .replace('__CARDS__', () => safe(cards))
  .replace('__LABELS__', () => safe(labels));
if (/__[A-Z_]+__/.test(out)) { console.error('unreplaced placeholder'); process.exit(1); }
fs.writeFileSync('drill.html', out);
console.log('drill.html bytes:', out.length);
