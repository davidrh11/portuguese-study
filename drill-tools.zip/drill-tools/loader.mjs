import fs from 'node:fs';
import vm from 'node:vm';

function stub() {
  const fn = function(){};
  const handler = {
    get(t, p) {
      if (p === Symbol.toPrimitive) return () => '';
      if (p === Symbol.iterator) return function*(){};
      if (p === 'then') return undefined;
      if (p === 'length') return 0;
      if (p === 'value' || p === 'textContent' || p === 'innerHTML') return '';
      return proxy;
    },
    set() { return true; },
    apply() { return proxy; },
    construct() { return proxy; },
    has() { return true; },
  };
  const proxy = new Proxy(fn, handler);
  return proxy;
}

export function loadGuide(path, probes) {
  const html = fs.readFileSync(path, 'utf8');
  const scripts = [...html.matchAll(/<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  const store = new Map();
  const ls = { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k,v) => store.set(k, String(v)), removeItem: k => store.delete(k) };
  const sandbox = {
    document: stub(), window: stub(), navigator: stub(), Audio: stub(), URL: stub(), Image: stub(),
    fetch: () => new Promise(()=>{}), setTimeout: () => 0, setInterval: () => 0, clearInterval(){}, clearTimeout(){},
    localStorage: ls, console: { log(){}, warn(){}, error(){} }, requestAnimationFrame(){}, speechSynthesis: stub(),
    Math, JSON, Object, Array, Set, Map, Date, String, Number, RegExp, Promise, Symbol, parseInt, parseFloat, isNaN, encodeURIComponent, decodeURIComponent,
  };
  const ctx = vm.createContext(sandbox);
  const errors = [];
  scripts.forEach((code, i) => {
    try { vm.runInContext(code, ctx, { timeout: 4000 }); }
    catch (e) { errors.push(`script ${i}: ${e.message}`); }
  });
  const out = {};
  for (const p of probes) {
    try { out[p] = JSON.parse(JSON.stringify(vm.runInContext(p, ctx))); }
    catch (e) { out[p] = undefined; errors.push(`probe ${p}: ${e.message}`); }
  }
  return { out, errors, scriptCount: scripts.length };
}
